function attachEvents() {
//nema faida brato jas nisto ne znam ovaa nemozav da ja resam
}

attachEvents();